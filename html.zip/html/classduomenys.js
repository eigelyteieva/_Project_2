var classduomenys =
[
    [ "duomenys", "classduomenys.html#aba90b5bfeb7394b6b1648a6a41f59db0", null ],
    [ "duomenys", "classduomenys.html#af00acbedd054d362a0ea7d2af231b806", null ],
    [ "~duomenys", "classduomenys.html#a312c1fcccbcaea0499e4b86eb9ebd162", null ],
    [ "getEgzamino_rez", "classduomenys.html#a83e623cac57edb7d0ca4c89ad79e54fd", null ],
    [ "getGalutinis_egz", "classduomenys.html#afdb1497fa30c4a1894f4e8c238830db6", null ],
    [ "getPavarde", "classduomenys.html#ad0cddcea573281d6bbeb476301409ba0", null ],
    [ "getPazymiai", "classduomenys.html#a9b4d41a307c11b7b0e2db59169c31e4d", null ],
    [ "getVardas", "classduomenys.html#ab302e1d5079502006a153ab74763c1b2", null ],
    [ "operator=", "classduomenys.html#ac5d7fc391319808b1fe0b38932521b94", null ],
    [ "setEgzamino_rez", "classduomenys.html#a8c3229182d93f8fd64324366460aaea3", null ],
    [ "setGalutinis_egz", "classduomenys.html#a516db7f6bf96a7d89ec6a10c04dad9c8", null ],
    [ "setPavarde", "classduomenys.html#ad612a24918bd8340c0d7adb69ecbd261", null ],
    [ "setPazymiai", "classduomenys.html#a57fcb3fd843b599d8aaa450359533f86", null ],
    [ "setVardas", "classduomenys.html#a05caad10cbbdfd3b575e10274d253e12", null ]
];