var searchData=
[
  ['setegzamino_5frez_0',['setEgzamino_rez',['../classzmogus.html#af49b85ba2d47b50e13b064ca80687533',1,'zmogus::setEgzamino_rez()'],['../classduomenys.html#a8c3229182d93f8fd64324366460aaea3',1,'duomenys::setEgzamino_rez()']]],
  ['setgalutinis_5fegz_1',['setGalutinis_egz',['../classzmogus.html#a0fbc2c6a68db510937837fc0649bbbe2',1,'zmogus::setGalutinis_egz()'],['../classduomenys.html#a516db7f6bf96a7d89ec6a10c04dad9c8',1,'duomenys::setGalutinis_egz()']]],
  ['setpavarde_2',['setPavarde',['../classzmogus.html#a33e3eb561d04e5eb0ee5a00de3b9f8e0',1,'zmogus::setPavarde()'],['../classduomenys.html#ad612a24918bd8340c0d7adb69ecbd261',1,'duomenys::setPavarde()']]],
  ['setpazymiai_3',['setPazymiai',['../classzmogus.html#a064e0c7f6b06166b0ed3bdecd2db289b',1,'zmogus::setPazymiai()'],['../classduomenys.html#a57fcb3fd843b599d8aaa450359533f86',1,'duomenys::setPazymiai()']]],
  ['setvardas_4',['setVardas',['../classzmogus.html#ac628548ed89f908195911befd7dca525',1,'zmogus::setVardas()'],['../classduomenys.html#a05caad10cbbdfd3b575e10274d253e12',1,'duomenys::setVardas()']]],
  ['skaitymas_5',['skaitymas',['../main_8cpp.html#adcf0e6cc46121649ef0d31c0c33f09dd',1,'main.cpp']]],
  ['spausdinimas_6',['spausdinimas',['../main_8cpp.html#a6889b0a04766ca916e1bdd1c96d3a152',1,'main.cpp']]],
  ['studentuskaiciaustikrinimas_7',['studentuskaiciaustikrinimas',['../main_8cpp.html#a30e76a15a27a234c9730e7d94995c01f',1,'main.cpp']]],
  ['sveikoskaiciauspatikrinimas_8',['sveikoSkaiciausPatikrinimas',['../main_8cpp.html#a9eb1b03a72db3af39c6ed4a5bbdb6d85',1,'main.cpp']]]
];
