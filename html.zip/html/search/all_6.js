var searchData=
[
  ['paskirstymas_0',['paskirstymas',['../main_8cpp.html#a103a883925382edad516ece54c81fc32',1,'main.cpp']]],
  ['paskirstymo_5fisve_1',['paskirstymo_isve',['../main_8cpp.html#a3ea93d72b3121b197e72ef838cbed80c',1,'main.cpp']]]
];
