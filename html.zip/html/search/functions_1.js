var searchData=
[
  ['duom_5fautomatinis_0',['duom_automatinis',['../main_8cpp.html#a18da73a28c3cb18da8c06bd50559f73a',1,'main.cpp']]],
  ['duom_5frankinis_1',['duom_rankinis',['../main_8cpp.html#a349d720ab3900ba1105c57b8bb17356c',1,'main.cpp']]],
  ['duomenys_2',['duomenys',['../classduomenys.html#aba90b5bfeb7394b6b1648a6a41f59db0',1,'duomenys::duomenys(string vardas, string pavarde, vector&lt; float &gt;pazymiai, float egzamino_rez, float galutinis_egz)'],['../classduomenys.html#af00acbedd054d362a0ea7d2af231b806',1,'duomenys::duomenys()']]]
];
