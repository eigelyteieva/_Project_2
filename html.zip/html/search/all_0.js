var searchData=
[
  ['automatiniai_5fpaz_0',['automatiniai_paz',['../main_8cpp.html#a07eb7820f0f8746aa349dfb81ce35cb9',1,'main.cpp']]]
];
