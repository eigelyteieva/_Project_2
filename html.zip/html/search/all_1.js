var searchData=
[
  ['getegzamino_5frez_0',['getEgzamino_rez',['../classzmogus.html#a7892326759ab044f921db027e69bb727',1,'zmogus::getEgzamino_rez()'],['../classduomenys.html#a83e623cac57edb7d0ca4c89ad79e54fd',1,'duomenys::getEgzamino_rez()']]],
  ['getgalutinis_5fegz_1',['getGalutinis_egz',['../classzmogus.html#a9b1d26fe51a0fc035324b4855c97d4f3',1,'zmogus::getGalutinis_egz()'],['../classduomenys.html#afdb1497fa30c4a1894f4e8c238830db6',1,'duomenys::getGalutinis_egz()']]],
  ['getpavarde_2',['getPavarde',['../classzmogus.html#a6529991c2d73a28de19efdf20bd82ca8',1,'zmogus::getPavarde()'],['../classduomenys.html#ad0cddcea573281d6bbeb476301409ba0',1,'duomenys::getPavarde()']]],
  ['getpazymiai_3',['getPazymiai',['../classzmogus.html#aa076c18c8615799447d6714db6e3126f',1,'zmogus::getPazymiai()'],['../classduomenys.html#a9b4d41a307c11b7b0e2db59169c31e4d',1,'duomenys::getPazymiai()']]],
  ['getvardas_4',['getVardas',['../classzmogus.html#a5da2a88b9d5fad41c5bc7c5a945d2d67',1,'zmogus::getVardas()'],['../classduomenys.html#ab302e1d5079502006a153ab74763c1b2',1,'duomenys::getVardas()']]]
];
