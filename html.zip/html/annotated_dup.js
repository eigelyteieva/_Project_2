var annotated_dup =
[
    [ "duomenys", "classduomenys.html", "classduomenys" ],
    [ "zmogus", "classzmogus.html", "classzmogus" ]
];