var classzmogus =
[
    [ "getEgzamino_rez", "classzmogus.html#a7892326759ab044f921db027e69bb727", null ],
    [ "getGalutinis_egz", "classzmogus.html#a9b1d26fe51a0fc035324b4855c97d4f3", null ],
    [ "getPavarde", "classzmogus.html#a6529991c2d73a28de19efdf20bd82ca8", null ],
    [ "getPazymiai", "classzmogus.html#aa076c18c8615799447d6714db6e3126f", null ],
    [ "getVardas", "classzmogus.html#a5da2a88b9d5fad41c5bc7c5a945d2d67", null ],
    [ "setEgzamino_rez", "classzmogus.html#af49b85ba2d47b50e13b064ca80687533", null ],
    [ "setGalutinis_egz", "classzmogus.html#a0fbc2c6a68db510937837fc0649bbbe2", null ],
    [ "setPavarde", "classzmogus.html#a33e3eb561d04e5eb0ee5a00de3b9f8e0", null ],
    [ "setPazymiai", "classzmogus.html#a064e0c7f6b06166b0ed3bdecd2db289b", null ],
    [ "setVardas", "classzmogus.html#ac628548ed89f908195911befd7dca525", null ]
];